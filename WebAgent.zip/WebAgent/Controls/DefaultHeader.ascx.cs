using System;
using System.Globalization;
using System.Threading;
using System.Web;
using System.Web.Security;

public partial class DefaultHeader : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void lblLogout_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session != null)
            {
                Session.Clear();
                Session.Abandon();
                FormsAuthentication.SignOut();
            }
        }
        catch { }
        Response.Redirect("../Pages/Login.aspx");
    }
}
